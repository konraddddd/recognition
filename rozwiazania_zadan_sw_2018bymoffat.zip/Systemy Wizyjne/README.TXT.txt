Autor: Krzyszczuk Micha�
e-mail: krzyszczuk.michal@gmail.com
www: https://michask.github.io/

Folder "Instrukcje" zawiera pliki z platformy UPEL, kt�rych autorami s� podpisani w nich prowadz�cy.
Komplet rozwi�zanych zada� laboratoryjnych znajduje si� w poszczeg�lnych folderach. S� w nich r�wnie� 
rozwi�zane zadania dodatkowe.

Prosz� o rozwa�ne korzystanie z powy�szych zasob�w.